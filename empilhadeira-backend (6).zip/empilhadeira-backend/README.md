# Backend para Sistema de Empilhadeira

Este é o backend Flask que gerencia a sincronização de dados entre o visualizador de empilhadeira e o Google Sheets.

## Funcionalidades

- Leitura de dados do Google Sheets
- Escrita de status e observações na planilha
- API REST para comunicação com o frontend
- Autenticação via Service Account do Google

## Estrutura do Projeto

```
src/
├── main.py                 # Arquivo principal do Flask
├── routes/
│   ├── sheets.py          # Rotas para Google Sheets API
│   └── user.py            # Rotas de usuário (template)
├── models/
│   └── user.py            # Modelos de dados (template)
└── solicitacao-empilhadeira-4bd263c9dac6.json  # Credenciais do Google
```

## Deploy

Este projeto está configurado para deploy automático no Render.com

## Configuração

As credenciais do Google Service Account estão incluídas no projeto para facilitar o deploy.

