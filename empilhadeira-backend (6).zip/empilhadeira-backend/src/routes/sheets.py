from flask import Blueprint, request, jsonify
from google.oauth2 import service_account
from googleapiclient.discovery import build
import os
import json
from datetime import datetime

sheets_bp = Blueprint('sheets', __name__)

# Configurações do Google Sheets
SHEET_ID = '1vmuL-OXeanaYhVFD4sKJpHWfITxSyXFixyOleMBk4RE'
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
SERVICE_ACCOUNT_FILE = os.path.join(os.path.dirname(__file__), '..', 'solicitacao-empilhadeira-4bd263c9dac6.json')

def get_sheets_service():
    """Cria e retorna o serviço do Google Sheets autenticado."""
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    service = build('sheets', 'v4', credentials=credentials)
    return service

@sheets_bp.route('/read-data', methods=['GET'])
def read_data():
    """Lê dados da planilha do Google Sheets."""
    try:
        service = get_sheets_service()
        sheet = service.spreadsheets()
        
        # Lê os dados da planilha
        result = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range='Dados!A:G'
        ).execute()
        
        values = result.get('values', [])
        
        if not values:
            return jsonify({'error': 'Nenhum dado encontrado'}), 404
        
        # Converte os dados para o formato esperado pelo frontend
        headers = values[0] if values else []
        rows = values[1:] if len(values) > 1 else []
        
        requests_data = []
        for index, row in enumerate(rows):
            # Preenche com strings vazias se a linha estiver incompleta
            while len(row) < 7:
                row.append('')
            
            request_data = {
                'id': f'EMP{str(index + 1).zfill(3)}',
                'timestamp': row[0] or '',
                'solicitante': row[1] or '',
                'area': row[2] or '',
                'tipoOperacao': row[3] or '',
                'codigoItem': row[4] or '',
                'tempoAtendimento': row[5] or '',
                'observacao': row[6] or '',
                'status': 'pendente',  # Status padrão
                'observacaoOperador': '',
                'horarioInicio': None,
                'horarioConclusao': None
            }
            requests_data.append(request_data)
        
        return jsonify({
            'success': True,
            'data': requests_data
        })
        
    except Exception as e:
        print(f"Erro ao ler dados: {str(e)}")
        return jsonify({'error': f'Erro ao ler dados: {str(e)}'}), 500

@sheets_bp.route('/update-status', methods=['POST'])
def update_status():
    """Atualiza o status de uma solicitação na planilha."""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        request_id = data.get('requestId')
        status = data.get('status')
        observacao_operador = data.get('observacaoOperador', '')
        horario_inicio = data.get('horarioInicio')
        horario_conclusao = data.get('horarioConclusao')
        
        if not request_id or not status:
            return jsonify({'error': 'requestId e status são obrigatórios'}), 400
        
        # Extrai o índice da linha a partir do ID (EMP001 -> linha 2, EMP002 -> linha 3, etc.)
        try:
            row_index = int(request_id.replace('EMP', '')) + 1  # +1 porque a linha 1 é o cabeçalho
        except ValueError:
            return jsonify({'error': 'ID de solicitação inválido'}), 400
        
        service = get_sheets_service()
        sheet = service.spreadsheets()
        
        # Primeiro, lê a linha atual para preservar os dados existentes
        current_range = f'Dados!A{row_index}:G{row_index}'
        current_result = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range=current_range
        ).execute()
        
        current_values = current_result.get('values', [[]])[0] if current_result.get('values') else []
        
        # Preenche com strings vazias se necessário
        while len(current_values) < 7:
            current_values.append('')
        
        # Adiciona as novas colunas para status, observação do operador, horários
        # Vamos usar as colunas H, I, J, K para: Status, Observação Operador, Horário Início, Horário Conclusão
        update_range = f'Dados!H{row_index}:K{row_index}'
        
        # Prepara os valores para atualização
        update_values = [
            status,
            observacao_operador,
            horario_inicio or '',
            horario_conclusao or ''
        ]
        
        # Atualiza a planilha
        body = {
            'values': [update_values]
        }
        
        result = sheet.values().update(
            spreadsheetId=SHEET_ID,
            range=update_range,
            valueInputOption='RAW',
            body=body
        ).execute()
        
        return jsonify({
            'success': True,
            'message': 'Status atualizado com sucesso',
            'updatedCells': result.get('updatedCells', 0)
        })
        
    except Exception as e:
        print(f"Erro ao atualizar status: {str(e)}")
        return jsonify({'error': f'Erro ao atualizar status: {str(e)}'}), 500

@sheets_bp.route('/read-status', methods=['GET'])
def read_status():
    """Lê os status atualizados da planilha."""
    try:
        service = get_sheets_service()
        sheet = service.spreadsheets()
        
        # Lê os dados das colunas de status (H:K)
        result = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range='Dados!H:K'
        ).execute()
        
        values = result.get('values', [])
        
        status_data = {}
        for index, row in enumerate(values):
            if index == 0:  # Pula o cabeçalho se existir
                continue
                
            request_id = f'EMP{str(index).zfill(3)}'
            
            # Preenche com strings vazias se a linha estiver incompleta
            while len(row) < 4:
                row.append('')
            
            status_data[request_id] = {
                'status': row[0] or 'pendente',
                'observacaoOperador': row[1] or '',
                'horarioInicio': row[2] or None,
                'horarioConclusao': row[3] or None
            }
        
        return jsonify({
            'success': True,
            'data': status_data
        })
        
    except Exception as e:
        print(f"Erro ao ler status: {str(e)}")
        return jsonify({'error': f'Erro ao ler status: {str(e)}'}), 500

@sheets_bp.route('/health', methods=['GET'])
def health_check():
    """Verifica se a conexão com o Google Sheets está funcionando."""
    try:
        service = get_sheets_service()
        sheet = service.spreadsheets()
        
        # Tenta fazer uma leitura simples para verificar a conexão
        result = sheet.values().get(
            spreadsheetId=SHEET_ID,
            range='Dados!A1:A1'
        ).execute()
        
        return jsonify({
            'success': True,
            'message': 'Conexão com Google Sheets OK',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"Erro na verificação de saúde: {str(e)}")
        return jsonify({
            'success': False,
            'error': f'Erro na conexão: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500

